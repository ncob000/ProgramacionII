# Proyecto final IS283

Nicolas Betancur Rios
Novienmbre / 2023-2

## Uso:

El proyecto esta estructurado de una forma donde cada directorio tiene un objetivo especifico,
en el directorio **src/main.cpp** hay mas especificaciones del proyecto.

## Compilacion

El proyecto se compila usando un script .bat, se puede compilar ejecutando el comando _build_ en un
CMD ( se debe ejecutar estando en el directorio raiz del proyecto ), la compilacion genera
un ejecutable en el directorio build, aun asi el proyecto ya esta compilado por default.
